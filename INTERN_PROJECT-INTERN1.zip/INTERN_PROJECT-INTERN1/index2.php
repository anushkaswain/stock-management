
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BREAKDOWN/STOCK</title>
    <style>
         .box-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 80vh;
            transition: transform 0.5s ease-in-out;
    }

        .box1 {
            width: 330px;
            height: 330px;
            display: inline-block;
            border: 8px solid black;
            padding: 10px 20px;
            box-sizing: border-box;
            cursor: pointer;
            margin: 20px 20px;
            text-align: center;
            background-image: url(breakdown.png);
            background-size: 100%;
            
        }
        
        .box2 {
            width: 330px;
            height: 330px;
            display: inline-block;
            border: 8px solid black;
            padding: 10px 20px;
            box-sizing: border-box;
            cursor: pointer;
            margin: 20px 20px;
            text-align: center;
            background-image: url(stock.png);
            background-size: 100% 100%;
            
        }
        .centered-image {
        display: flex;
        justify-content: center;
        align-items: center;
        
        }

        .picture {
            display: flex;
            justify-content: center;
            align-items: center;
            display: inline-block;
    }
        .box1:hover{
            transform: translateY(-20px);
        }
        .box2:hover{
            transform: translateY(-20px);
        }
    
</style>



<div class="centered-image">
    <img src="MCL_logo.png" alt="MCL" width="250" />
    
</div>
        
    </style>
</head>
<body> 
<a href="breakdown_dashboard.php"> 
   
<diV class="box-container">
        <div class="box1" id="BREAKDOWN ">
        
        <h2 style="background-color:aliceblue" style="color: black;"> BREAKDOWN MANAGEMENT </h2>
        </div>
        
    <a href="dashboard.php">
    <div 
    class="box2" id="STOCK">
        <h2 style="background-color: aliceblue" style="color: red;">STOCK MANAGEMENT</h2>  
            
    </div>
    

    </div>
</body>
</html>