<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BREAKDOWN/STOCK</title>
    <style>
         .box-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 80vh;
            transition: transform 0.5s ease-in-out;
            font-family: Arial, Helvetica, sans-serif;
    }

        .box1 {
            width: 450px;
            height: 500px;
            display: inline-block;
            border: 6px solid black;
            padding: 10px 20px;
            box-sizing: border-box;
            cursor: pointer;
            margin: 20px 20px;
            text-align: center;
            background-image: url(breakdown.png);
            background-size: 100%;
            border-radius: 20px;
            
        }
        
        .box2 {
            width: 450px;
            height: 500px;
            display: inline-block;
            border: 6px solid black;
            padding: 10px 20px;
            box-sizing: border-box;
            cursor: pointer;
            margin: 20px 20px;
            text-align: center;
            background-image: url(stock.png);
            background-size: 100% 100%;
            border-radius: 20px;
            
        }
        .centered-image {
        display: flex;
        justify-content: center;
        align-items: center;
        
        
        }
      
        img{
            border-radius: 4px;
            background-color: white;
            border:2px solid black;
        }
        .picture {
            display: flex;
            justify-content: center;
            align-items: center;
            display: inline-block;
    }
        .box1:hover{
            transform: translateY(-20px);
        }
        .box2:hover{
            transform: translateY(-20px);
        }
    
</style>
<style>
body {
      background-image: url("opoy7.jpg");
      /* background-color: coral; */
      background-repeat: no-repeat;
      background-size: cover;
    }

</style>

<div class="centered-image">
    <img src="MCL_logo.png" alt="MCL" width="150" />
    
</div>
        
    </style>
</head>
<body> 
<a href="breakdown_dashboard.php"> 
   
<diV class="box-container">
        <div class="box1" id="BREAKDOWN ">
        
        <h2 style="color: black;"> BREAKDOWN MANAGEMENT </h2>
        </div>
        
    <a href="dashboard.php">
    <div 
    class="box2" id="STOCK">
        <h2 style="color:brown;">STOCK MANAGEMENT</h2>  
            
    </div>
    

    </div>
</body>
</html>